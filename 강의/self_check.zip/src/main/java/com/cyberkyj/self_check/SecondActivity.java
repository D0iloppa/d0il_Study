package com.cyberkyj.self_check;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SecondActivity extends AppCompatActivity {

    int calValue = 0;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        intent = getIntent();

        String calc = intent.getStringExtra("Calc");


        if (calc.equals("+")) {
            calValue = intent.getIntExtra("Num1", 0)
                    + intent.getIntExtra("Num2", 0);
        } else if (calc.equals("-")) {
            calValue = intent.getIntExtra("Num1", 0)
                    - intent.getIntExtra("Num2", 0);
        } else if (calc.equals("*")) {
            calValue = intent.getIntExtra("Num1", 0)
                    * intent.getIntExtra("Num2", 0);
        } else {
            calValue = intent.getIntExtra("Num1", 0)
                    / intent.getIntExtra("Num2", 0);
        }



        Button btnReturn = findViewById(R.id.btnReturn);
        btnReturn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                intent.putExtra("Hap", calValue);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }

}
