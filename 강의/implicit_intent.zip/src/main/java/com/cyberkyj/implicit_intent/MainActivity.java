package com.cyberkyj.implicit_intent;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.speech.RecognitionService;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import static android.content.Intent.ACTION_PICK;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button contactsBtn, cameraBtn, speechBtn, mapBtn, browserBtn, callBtn;
    TextView resultView;
    ImageView imageView;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contactsBtn = findViewById(R.id.btn_Contacts);
        cameraBtn = findViewById(R.id.btn_Camera);
        speechBtn = findViewById(R.id.btn_Speech);
        mapBtn = findViewById(R.id.btn_Map);
        browserBtn = findViewById(R.id.btn_Browser);
        callBtn = findViewById(R.id.btn_Call);

        resultView = findViewById(R.id.resultView);
        imageView = findViewById(R.id.imageView);

        contactsBtn.setOnClickListener(this);
        cameraBtn.setOnClickListener(this);
        speechBtn.setOnClickListener(this);
        mapBtn.setOnClickListener(this);
        browserBtn.setOnClickListener(this);
        callBtn.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {

        if(v==contactsBtn){

            intent = new Intent(Intent.ACTION_PICK);
           //intent.setData(ContactsContract.Contacts.CONTENT_URI); //사람이름
            intent.setData(ContactsContract.CommonDataKinds.Phone.CONTENT_URI);//사람이름과 전화번호
            startActivityForResult(intent, 10);


            /*intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(ContactsContract.Contacts.CONTENT_URI+"/"+219));
            startActivity(intent);*/


        }else if(v==cameraBtn){

            intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent,20);

        }else if(v==speechBtn){
            //사람의 말을 구글 서버에 전달하여 그 곳에서 문자열로 변환하고 변환된 문자열을 반환받는 방식
            intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            //LANGUAGE_MODEL_FREE_FORM: 일반적인 음성에 대한 문자열 변환 서비스
            //LANGUAGE_MODEL_WEB_SEARCH: 웹 검색 조건에 기반을 둔 언어모델
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            //음성을 받아들이기 위해 다이얼로그를 띄우는데, 그 때 다이얼로그의 타이들 문자열임
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT,"음성인식 테스트");
            startActivityForResult(intent,30);

        }else if(v==mapBtn){
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:35.833668, 127.137901"));
            startActivity(intent);

        }else if(v==browserBtn){
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://m.naver.com"));
            startActivity(intent);

        }else if(v==callBtn){
            if(ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)== PackageManager.PERMISSION_GRANTED){
                intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:010-8603-3706"));
                startActivity(intent);
            }else{
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE},100);
            }

        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==10 && resultCode==RESULT_OK){
            //URL 정보의 마지막 숫자가 선택한 사람의 식별자가 됨(주소록의 id)
            //이런식으로 식별자 값을 얻은 후 구체적인 전화번호나 이메일등의 값을 다시 가져와야 함
            String result = data.getDataString();
            resultView.setText(result);
        }else if(requestCode==20 && resultCode==RESULT_OK){
            Bitmap bitmap = (Bitmap)data.getExtras().get("data");
            imageView.setImageBitmap(bitmap);
        }else if(requestCode==30 && resultCode==RESULT_OK){
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            String result = results.get(0);
            resultView.setText(result);
        }
    }
}